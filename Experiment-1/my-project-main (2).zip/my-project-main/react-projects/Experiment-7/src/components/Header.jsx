function Header() {
    return (
    <header>
        <h1>Welcome Page</h1>
    </header>
    );
}

export default Header;
