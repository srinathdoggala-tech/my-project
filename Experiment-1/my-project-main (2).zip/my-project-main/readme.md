# Full Stack Web Development Experiments

This repository contains my **Full Stack Web Development experiments**.  
Currently, I am working on the **Frontend** part (HTML, CSS, JavaScript) where I am learning concepts like DOM manipulation, styling, event handling, and interactivity.  

The plan is to gradually move towards **backend development** and finally complete the **full stack journey** step by step.  

## Progress
- ✅ Frontend (in progress)  
- 🔜 Backend  
- 🔜 Database Integration  
- 🔜 Full Stack Projects  

Stay tuned as this repo will be updated regularly with my progress 🚀
